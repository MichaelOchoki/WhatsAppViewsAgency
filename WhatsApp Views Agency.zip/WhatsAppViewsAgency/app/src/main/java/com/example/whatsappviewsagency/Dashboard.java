package com.example.whatsappviewsagency;

import static android.R.layout.simple_list_item_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.net.URLEncoder;

public class Dashboard extends AppCompatActivity {

    ImageView whatsapp_icon;
    ImageView fb_icon;
    ImageView email_icon;
    ImageView telegram_icon;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        listView = findViewById(R.id.listView);


        ImageView share_icon = findViewById(R.id.share_icon);

        share_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setDataAndType(Uri.parse("email"), "message/rfc822");
                Intent chooser = Intent.createChooser(intent, "Launch E-mail");
                startActivity(chooser);

            }
        });

        //launch whatsapp and send message

        ImageView whatsapp_icon = findViewById(R.id.whatsapp_icon);

        whatsapp_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("whatsapp://send?phone="+ "+92300xxxxxxx" +"&text=" + URLEncoder.encode("Hello :) \n\n Make money by simply posting an ad on your WhatsApp! \n\n\n\n Download app here:[play_store_link]\"", "UTF-8")));
                    startActivity(i);
                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Whatsapp not installed!", Toast.LENGTH_LONG).show();
                }
            }
        });


        ImageView fb_icon = findViewById(R.id.fb_icon);

        fb_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("facebook://send?phone="+ "&text=" + URLEncoder.encode("Hello \n\n Make money by simply posting an ad on your WhatsApp! \n\n\n\n Download app here:[play_store_link]\"", "UTF-8")));
                    startActivity(i);
                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Facebook not installed!", Toast.LENGTH_LONG).show();
                }

            }
        });

        ImageView telegram_icon = findViewById(R.id.telegram_icon);

        telegram_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("telegram://send?phone="+ "+92300xxxxxxx" +"&text=" + URLEncoder.encode("Hello :) \n\n Make money by simply posting an ad on your WhatsApp! \n\n\n\n Download app here:[play_store_link]\"", "UTF-8")));
                    startActivity(i);
                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Telegram not installed!", Toast.LENGTH_LONG).show();
                }

            }
        });

        ImageView email_icon = findViewById(R.id.email_icon);

        email_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setDataAndType(Uri.parse("email"), "message/rfc822");
                String[]email = {"somebody@gmail.com"};
                intent.putExtra(intent.EXTRA_EMAIL, email);
                intent.putExtra(intent.EXTRA_SUBJECT, "REF:WHATSAPP VIEWS AGENCY");
                intent.putExtra(intent.EXTRA_TEXT, "Hello [name]\n\n Make money by simply posting an ad on your WhatsApp! \n\n\n\n Download app here:[play_store_link]"
                );
                Intent chooser = Intent.createChooser(intent, "Launch E-mail");
                        startActivity(chooser);


            }
        });

        ListView listView = findViewById(R.id.listView);

        final String[] text = {"Click here for today's Ad", "Click here to send your Views",
                "Click here to submit your Referral's details", "Talk to us..."};


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, simple_list_item_1, text);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch (position) {
                    case 0:
                        Intent i = new Intent(Dashboard.this, Ad.class);
                        startActivity(i);

                        break;
                    case 1:

                        Intent intent = new Intent(Dashboard.this, Views.class);
                        startActivity(intent);

                        break;
                    case 2:
                        Intent intent2 = new Intent(Dashboard.this, Referrals.class);
                        startActivity(intent2);
                    case 3:
                        Intent intent3 = new Intent(Dashboard.this, Contact.class);
                        startActivity(intent3);
                    //    break;
                    //case 4:
                    //    Toast.makeText(getApplicationContext(), "Shared successfully!", Toast.LENGTH_SHORT).show();

                        /*
                         * OR
                         *
                         * YOU CAN TRY THIS
                         *
                         * Toast.makeText(getApplicationContext(),text[position], Toast.LENGTH_SHORT).show();
                         *
                         * */


                }
            }
        });
    }
}