package com.example.whatsappviewsagency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Contact extends AppCompatActivity {

    TextView question;
    EditText message;
    Button submit_question;
    Button upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        TextView question = findViewById(R.id.question);
        question.setText("Do you have an question?\n Feel free to contact our team!");


        Button submit_question = findViewById(R.id.submit_question);
        submit_question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Contact.this, Dashboard.class); //will direct to implicit whatsapp or phone or sms
                startActivity(i);

                Toast.makeText(getApplicationContext(), "Sent successfully!", Toast.LENGTH_SHORT).show();
            }
        });



        //Button upload = findViewById(R.id.upload);
    }
}