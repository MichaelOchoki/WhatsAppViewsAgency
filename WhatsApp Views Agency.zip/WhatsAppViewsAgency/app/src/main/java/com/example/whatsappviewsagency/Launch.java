package com.example.whatsappviewsagency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Launch extends AppCompatActivity {

    TextView welcome;
    Button okay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);

        TextView welcome = (TextView) findViewById(R.id.welcomeText);
        welcome.setText("Welcome to WhatsApp Views Agency where you make money from your WhatsApp Status!\n\nTo Login, please pay to recieve your login Username & Password.\n\n" +
                "PAYBILL NO: \n\n Customer care: +254 704 706301");

        Button okay = findViewById(R.id.okay);

        okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Launch.this, Login.class);
                startActivity(i);
            }
        });
    }


}