package com.example.whatsappviewsagency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Referrals extends AppCompatActivity {

    TextView referral_text;
    TextView referral_text2;
    Button submit_ref;
    Button upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_referrals);

        TextView rt = findViewById(R.id.referral_text);
        rt.setText("Send the details of the person who referred you to our App plus the screenshot of the referral so we can pay them a commission!");

        TextView rt2 = findViewById(R.id.referral_text2);
        rt2.setText("YOU CAN ALSO EARN MONEY BY REFERRING YOUR FRIENDS TO US!");


        Button submit_ref = findViewById(R.id.submit_ref);
        submit_ref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Referrals.this, Dashboard.class);
                startActivity(i);

                Toast.makeText(getApplicationContext(), "Sent successfully!", Toast.LENGTH_SHORT).show();
            }
        });



        //Button upload = findViewById(R.id.upload);
    }
}