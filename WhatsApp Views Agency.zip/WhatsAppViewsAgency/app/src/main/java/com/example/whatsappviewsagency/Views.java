package com.example.whatsappviewsagency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Views extends AppCompatActivity {

    TextView send_views;
    Button submit_views;
    Button upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_views);

        TextView send_views = findViewById(R.id.send_views);
        send_views.setText("Take a screenshot of your WhatsApp Views and upload to recieve your payment!");

        Button submit_views = findViewById(R.id.submit_views);
        submit_views.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Views.this, Launch.class);
                finish();

                Toast.makeText(getApplicationContext(), "Sent successfully!", Toast.LENGTH_SHORT).show();
            }
        });



        Button upload = findViewById(R.id.upload);
    }
}