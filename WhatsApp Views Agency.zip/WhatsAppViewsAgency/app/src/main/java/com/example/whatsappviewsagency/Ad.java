package com.example.whatsappviewsagency;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;

public class Ad extends AppCompatActivity {

    TextView post_ad;
    Button download;
    ImageView ad;
    File file;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad);

        TextView post_ad = (TextView) findViewById(R.id.post_ad);
        post_ad.setText("Download and post the following Ad on your WhatsApp Status:");

        Button download = findViewById(R.id.download);

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View ad ) {
                // TODO Auto-generated method stub
                //attempt to save the image

                ad = findViewById(R.id.omo_ad);
                ad.setDrawingCacheEnabled(true);
                    Bitmap bitmap = ad.getDrawingCache();
                    File file = new File("Phone/DCIM/Camera/image.jpg");
                    File root = Environment.getExternalStorageDirectory();
                    File cachePath = new File(root.getAbsolutePath() + "Phone/DCIM/Camera/image.jpg");
                    try
                    {
                        cachePath.createNewFile();
                        FileOutputStream ostream = new FileOutputStream(cachePath);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, ostream);
                        ostream.close();
                    }
                    catch (Exception e)
                    {
                    e.printStackTrace();
                    }


            }
        });
    }
}